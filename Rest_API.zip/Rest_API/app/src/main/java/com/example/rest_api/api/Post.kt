package com.thanushaw.restretrofit_219.api

data class Post(val userId:Int,val id:Int,val title:String,val body:String)